class LaTeXParsingError(Exception):
    pass
