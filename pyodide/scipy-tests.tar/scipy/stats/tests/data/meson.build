py3.install_sources([
    '_mvt.py',
    'fisher_exact_results_from_r.py',
    'rel_breitwigner_pdf_sample_data_ROOT.npy',
    'studentized_range_mpmath_ref.json'
  ],
  subdir: 'scipy/stats/tests/data'
)

subdir('levy_stable')
subdir('nist_anova')
subdir('nist_linregress')
