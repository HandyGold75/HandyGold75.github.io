# (C) Copyright 2005-2023 Enthought, Inc., Austin, TX
# All rights reserved.
#
# This software is provided without warranty under the terms of the BSD
# license included in LICENSE.txt and may be redistributed only under
# the conditions described in the aforementioned license. The license
# is also available online at http://www.enthought.com/licenses/BSD.txt
#
# Thanks for using Enthought open source!

""" A filter to be used with FilteredTraitObserver for observing all
traits. """


def anytrait_filter(name, ctrait):
    """ Match filter that matches all traits.

    Parameters
    ----------
    name : str
        Name of the trait.
    ctrait : CTrait
        The actual trait.
    """
    return True
